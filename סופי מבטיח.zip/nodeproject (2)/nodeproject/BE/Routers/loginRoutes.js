const dbSingleton = require("../../DB/dbSingelton");
const db = dbSingleton.getConnection();
const express = require("express");
const router = express.Router();
//middlewear שבודק האם משתמש קיים כבר במערכת
const validateUserExistance = (req, res, next) => {
  const { userName } = req.body;
  const query = "select * From users WHERE userName=?";
  db.query(query, [userName], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    console.log(results[0]);
    if (results.length > 0) {
      return res.status(409).json({ message: "User already exists" });
    } else next();
  });
};
//middlewear שבודק האם קיים משתמש עם הפרטים שהוכנסו
const validateLogin = (req, res, next) => {
  const { userName, password } = req.body;
  const query = "select * From users WHERE userName=? and password=?";
  db.query(query, [userName, password], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    console.log(results[0]);
    if (results.length > 0) {
      req.session.user =  userName ;
      
      next();
    } else return res.status(409).json({ message: "User doesnt exists" });
  });
};
//בקשה שמכילה רק /login תשלח את המשתמש לדף הלוגין
router.get("/", (req, res, next) => {
  res.redirect("../login.html");
});
//פונקציה מתנתקת מהסשן ומחזירה מתשמש לדף הלוגין
router.post("/logout", (req, res, next) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send("Error terminating session.");
    }
    res.redirect("../login.html");
  });
  
});
//הרשמה, בודקת גם שהמשתמש לא קיים כבר ואם לא מכניסה אותו לבסיס הנתונים
router.post("/register", validateUserExistance, (req, res, next) => {
  const { userType, userName, email,age, password,city } = req.body;
  const query =
    "INSERT INTO users (userType, userName, password,email,age,city) VALUES (?, ?, ?,?,?,?)";
  db.query(
    query,
    [userType, userName, password, email, age,city],
    (err, results) => {
      if (err) {
        res.status(500).send(err);
        return;
      }

      res.redirect("/login.html");
    },
  );
});
//לוגין, בודקת שקיים משתמש ואם כן מקדמת אותו לדף הבית
router.post("/registered", validateLogin, (req, res, next) => {
  res.redirect("/home.html");
});

//מחזירה את שם המשתמש המחובר כרגע לסשן
router.get('/getUserName', (req, res, next) => {
  if(req.session){console.log(req.session)}
  const username = req.session.user;
  if (!username) return res.json({ userName: null });
  return res.json({ userName: username });
});

module.exports = router;
