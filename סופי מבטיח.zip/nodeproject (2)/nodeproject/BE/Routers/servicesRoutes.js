const express = require("express");
const router = express.Router();

const dbSingleton = require("../../DB/dbSingelton");
const db = dbSingleton.getConnection();
//מחזיר את כל השירותים הקיימים בבסיס הנתונים
router.get("/", (req, res) => {
  const q = `
    SELECT
      *
    FROM services
  `;
  db.query(q, (err, result) => {
    if (err) return res.status(500).send(err);
    res.status(200).json(result);
  });
});
module.exports = router;
