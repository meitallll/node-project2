const modal = document.getElementById('addEventModal');
const openBtn = document.getElementById('openAddEvent');
const closeBtn = document.getElementById('closeAddEvent');
const cancelBtn = document.getElementById('cancelAddEvent');
//הצגת החלונית של אירוע
openBtn.onclick = () => {
  modal.style.display = 'flex';
};
//הסתרת חלונית של אירוע
function closeModal() {
  modal.style.display = 'none';
}

closeBtn.onclick = closeModal;
cancelBtn.onclick = closeModal;

const eventsListEl = document.getElementById('eventsList');
//משנה את צבע הסטטוס באירוע
function statusColor(status) {
  if (!status) return '#666';
  const s = status.toLowerCase();
  if (s === 'active' || status === 'פעיל') return 'green';
  if (s === 'finished' || status === 'הסתיים') return 'blue';
  return '#666';
}
// מייצר כרטיסייה של אירוע עבור כלל האירועים ומייבאת את שם הצלם של האירוע
function renderEvents(events) {
  if (!events || events.length === 0) {
    eventsListEl.innerHTML = `<p class="card-info">אין אירועים להצגה.</p>`;
    return;
  }

  const html = events
    .map(ev => {
      const name = ev.name ?? '';
      const date = ev.date ?? '';
      const place = ev.place ?? '';
      const photographerId = ev.photographer_id ?? '';
      const status = ev.status ?? '';

      return `
        <div class="card">
          <h3>${name}</h3>
          <p class="card-info">תאריך: ${date}</p>
          <p class="card-info">מקום: ${place}</p>
          <p class="card-info" id="photog-${ev.id}">צלם: טוען...</p>
          <p class="card-info" style="color: ${statusColor(
            status,
          )};">סטטוס: ${status}</p>
          <div class="card-actions">
            <button class="btn-small" type="button" onclick="deleteEvent(${
              ev.id
            })">מחק</button>
            <button class="btn-small btn-secondary" type="button"
              onclick="fillFormForUpdate(${
                ev.id
              }, '${name}', '${date}', '${place}', '${photographerId}', '${status}')">
              עדכן
            </button>
          </div>
        </div>
      `;
    })
    .join('');

  eventsListEl.innerHTML = html;

  events.forEach(ev => {
    const el = document.getElementById(`photog-${ev.id}`);
    if (!el) return;

    const photographerId = ev.photographer_id;
    if (photographerId == null || photographerId === '') {
      el.innerText = 'צלם: לא נמצא';
      return;
    }

    fetch('/events/getPhotogId', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ photographerId }),
    })
      .then(async res => {
        if (!res.ok) {
          const text = await res.text();
          throw new Error(`HTTP ${res.status}: ${text}`);
        }
        return res.json();
      })
      .then(data => {
        const userName = data?.[0]?.userName ?? 'לא נמצא';
        el.innerText = `צלם: ${userName}`;
      })
      .catch(err => {
        console.error('getPhotogId failed:', err, {
          photographerId,
          evId: ev.id,
        });
        el.innerText = 'צלם: שגיאה';
      });
  });
}
//פונקציה מייבאת אירועים מבסיס הנתונים ומיישמת את הפונקציה  הקודמת בבניית הכרטיסיות
async function loadEvents() {
  try {
    const res = await fetch('/events');
    if (!res.ok) {
      eventsListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (סטטוס ${res.status})</p>`;
      return;
    }

    const events = await res.json();
    renderEvents(events);
  } catch (err) {
    console.log(err);
    eventsListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (תקלה בחיבור)</p>`;
  }
}

loadEvents();

//מציג פופ אפ עם ההודעה שקיבל
// function showPopup(message) {
//   const popup = document.getElementById('popupAlert');
//   popup.querySelector('p').innerText = message;
//   popup.classList.add('show');
//   setTimeout(() => popup.classList.remove('show'), 2500);
// }

const form = document.getElementById('addEventForm');

function showPopup(message) {
  const popup = document.querySelector('.popupAlert');
  popup.querySelector('p').innerText = message;
  popup.classList.add('show');

  setTimeout(() => {
    popup.classList.remove('show');
  }, 1500);
}
//הוספת אירוע וזריקת פופאפ בהתאם
form.addEventListener('submit', async e => {
  e.preventDefault();

  const body = new URLSearchParams(new FormData(form));

  const res = await fetch(form.action, {
    method: 'POST',
    body: body,
  });

  const text = await res.text();

  if (text === 'success') {
    showPopup('Event added successfully');
    form.reset();
    closeModal();
    loadEvents();
  } else if (text === 'no photographer found') {
    showPopup('no photographer found ');
  } else {
    showPopup('fail');
  }
});
//פתיחת חלונית הוספת אירוע
function openModal() {
  document.getElementById('eventModalUpdate').classList.add('open');
}

//סגירת חלונית הוספת אירוע
function closeUpdateModal() {
  document.getElementById('eventModalUpdate').classList.remove('open');
}

const cancelUpdateBtn = document.getElementById('cancelUpdateEvent');
if (cancelUpdateBtn) {
  cancelUpdateBtn.addEventListener('click', () => {
    closeUpdateModal();
  });
}
//ממלא פרטי אירוע בחלונית של עריכת האירוע
function fillFormForUpdate(id, name, date, place, photographerId, status) {
  fetch('/events/getPhotogId', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ photographerId }),
  })
    .then(async res => {
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`HTTP ${res.status}: ${text}`);
      }
      return res.json();
    })
    .then(data => {
      const userName = data?.[0]?.userName ?? 'לא נמצא';
      document.getElementById('eventPhotographer').value = userName || '';
      document.getElementById('eventId').value = id;
      document.getElementById('eventName').value = name || '';

      function toISODate(dateStr) {
        const [day, month, year] = dateStr.split('/');
        return `${year}-${month}-${day}`;
      }
      const fixedDate = toISODate(date);
      document.getElementById('eventDate').value = fixedDate || '';
      document.getElementById('eventLocation').value = place || '';

      const val =
        status === 'finished' || status === 'הסתיים' ? 'finished' : 'active';

      const radio = document.querySelector(
        `input[name="eventStatus"][value="${val}"]`,
      );
      if (radio) radio.checked = true;

      openModal();
    });
}

const form2 = document.getElementById('updateEventForm');
//עדכון אירוע לפי id
if (form2) {
  form2.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('eventId').value;

    const body = {
      photographerName: document.getElementById('eventPhotographer').value,
      name: document.getElementById('eventName').value,
      date: document.getElementById('eventDate').value,
      place: document.getElementById('eventLocation').value,
      status: document.querySelector('input[name="eventStatus"]:checked').value,
    };

    const res = await fetch(`/events/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const serverText = await res.text();
    console.log('PUT status:', res.status, 'response:', serverText);
    closeUpdateModal();

    if (!res.ok) {
      showPopup('שגיאה בעדכון');
      return;
    }

    showPopup('עודכן בהצלחה!');

    document.getElementById('eventId').value = '';
    e.target.reset();
    loadEvents();
  });
}
//מחיקת אירוע
async function deleteEvent(id) {
  const ok = confirm('האם אתה בטוח שאתה רוצה למחוק את האירוע?');
  if (!ok) return;
  try {
    const res = await fetch(`/events/${id}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      showPopup('שגיאה במחיקה');
      return;
    }

    loadEvents();
  } catch (err) {
    console.log(err);
    showPopup('שגיאה בחיבור לשרת');
  }
}
