const usernameEls = document.querySelectorAll('.helloUser');
//פונקציה מייבאת שם משתמש מבסיס הנתונים
async function changeUsername() {
  const res = await fetch('/login/getUserName');

  if (!res.ok) {
    throw new Error('Failed to fetch username');
  }

  const data = await res.json();
  return data.userName;
}
//פונקציה מקבלת שם משתמש של הסשן ומשנה אותו בhtml 
async function updateUsernameOnPage() {
  try {
    const userName = await changeUsername();
    if (userName != null) {
      console.log(userName + ' At the function');
      usernameEls.forEach(el => {
        el.textContent = 'שלום, ' + userName;
      });
    }
  } catch (err) {
    console.error(err);
  }
}
//בעליית העמוד פונקציה מעדכנת את שם המשתמש
window.addEventListener('DOMContentLoaded', () => {
  updateUsernameOnPage();
});
