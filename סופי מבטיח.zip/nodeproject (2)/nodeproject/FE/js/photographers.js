const PhotogListEl = document.getElementById("photogList");
//פונקציה מייצרת "קוביות" של צלמים
function renderPhotographers(photographers) {
  if (!photographers || photographers.length === 0) {
    PhotogListEl.innerHTML = `<p class="card-info">אין צלמים להצגה.</p>`;
    return;
  }

  const html = photographers
    .map((ev) => {
      const name = ev.userName ?? "";
      const age = ev.age ?? "";
      const email = ev.email ?? "";
      const city = ev.city ?? "";

      return `
      <div class="card">
        <h3>${name}</h3>
        <p class="card-info">גיל: ${age}</p>
        <p class="card-info">אימייל : ${email}</p>
        <p class="card-info">עיר מגורים : ${city}</p>
      </div>
    `;
    })
    .join("");

  PhotogListEl.innerHTML = html;
}
//פונקציה מייבאת את הצלמים מבסיס הנתונים ומשתמשת בפונקציה הקודמת ליצור אותם
async function loadPhotographers() {
  try {
    const res = await fetch("/photogs");
    if (!res.ok) {
      PhotogListEl.innerHTML = `<p class="card-info">שגיאה בטעינת צלמים (סטטוס ${res.status})</p>`;
      return;
    }

    const photogs = await res.json();
    renderPhotographers(photogs);
  } catch (err) {
    console.log(err);
    PhotogListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (תקלה בחיבור)</p>`;
  }
}

loadPhotographers();

