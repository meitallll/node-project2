const servicesListEl = document.getElementById("services");
//פונקצייה מייצרת כרטיסייה של שירותים
function renderServices(Services) {
  if (!Services || Services.length === 0) {
    servicesListEl.innerHTML = `<p class="card-info">אין שירותים להצגה.</p>`;
    return;
  }

  const html = Services.map((ev) => {
    const name = ev.type ?? "";
    

    return `
      <div class="service">
        <h3>${name}</h3>
      </div>
    `;
  }).join("");

  servicesListEl.innerHTML = html;
}
//פונקציה מייבאת את שירותים מבסיס הנתונים ומשתמשת בפונקציה הקודמת ליצור אותם
async function loadservices() {
  try {
    const res = await fetch("/services");
    if (!res.ok) {
      servicesListEl.innerHTML = `<p class="card-info">שגיאה בטעינת שירותים (סטטוס ${res.status})</p>`;
      return;
    }

    const services = await res.json();
    renderServices(services);
  } catch (err) {
    console.log(err);
    servicesListEl.innerHTML = `<p class="card-info">שגיאה בטעינת שירותים (תקלה בחיבור)</p>`;
  }
}

loadservices();
