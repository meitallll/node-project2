const path = require("path");

const express = require("express");
const loginRoutes = require("./Routers/loginRoutes");
const app = express();
const port = process.env.PORT || 3000;



app.use(express.static(path.join(__dirname, "../FE")));
app.use(express.urlencoded({ extended: false }));



app.use("/login", loginRoutes);



// if url is not found:
app.use((req, res, next) => {
  res.status(200).sendFile(path.join(__dirname, "../FE", "login.html"));
});

app.listen(port);
