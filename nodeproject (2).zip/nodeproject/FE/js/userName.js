const usernameEls = document.querySelectorAll('.helloUser');

async function changeUsername() {
  const res = await fetch('/login/getUserName');

  if (!res.ok) {
    throw new Error('Failed to fetch username');
  }

  const data = await res.json();
  return data.userName;
}

async function updateUsernameOnPage() {
  try {
    const userName = await changeUsername();
    if (userName != null) {
      console.log(userName + ' At the function');
      usernameEls.forEach(el => {
        el.textContent = 'שלום, ' + userName;
      });
    }
  } catch (err) {
    console.error(err);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  updateUsernameOnPage();
});
