// Switch between login and register forms
function showLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('registerForm').style.display = 'none';
}

function showRegister() {
  document.getElementById('registerForm').style.display = 'block';
  document.getElementById('loginForm').style.display = 'none';
}

// Validation functions
function validateUsername(username) {
  if (username.length < 2) return false;

  for (let ch of username) {
    if (
      !(
        (ch >= 'a' && ch <= 'z') ||
        (ch >= 'A' && ch <= 'Z') ||
        (ch >= 'א' && ch <= 'ת')
      )
    ) {
      return false;
    }
  }
  return true;
}
function validateAge(age) {
  if (age > 120 || age < 0) return false;
  else return true;
}

function validatePassword(password) {
  if (password.length < 3 || password.length > 8) return false;

  let hasLetter = false;
  let hasNumber = false;

  for (let ch of password) {
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
      hasLetter = true;
    } else if (ch >= '0' && ch <= '9') {
      hasNumber = true;
    }
  }

  return hasLetter && hasNumber;
}
document.addEventListener('DOMContentLoaded', () => {
  const loginBtn = document.getElementById('loginBtn');
  const loginUserName = document.getElementById('loginUsername');
  const loginPass = document.getElementById('loginPassword');

  // If any are null, IDs or script loading is wrong
  console.log({ loginBtn, loginUserName, loginPass });

  if (!loginBtn || !loginUserName || !loginPass) return;

  function loginValidation() {
    return (
      validateUsername(loginUserName.value) && validatePassword(loginPass.value)
    );
  }

  function updateLoginButton() {
    loginBtn.disabled = !loginValidation();
  }

  // initial state
  updateLoginButton();

  // update while typing
  loginUserName.addEventListener('input', updateLoginButton);
  loginPass.addEventListener('input', updateLoginButton);

  // also update when focusing (sometimes helpful)
  loginUserName.addEventListener('focus', updateLoginButton);
  loginPass.addEventListener('focus', updateLoginButton);
});
