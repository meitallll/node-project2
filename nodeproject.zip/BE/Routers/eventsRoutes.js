const express = require("express");
const router = express.Router();

const dbSingleton = require("../../DB/dbSingelton");
const db = dbSingleton.getConnection();

router.get("/", (req, res) => {
  const q = `
    SELECT
  id,
  photographer_id,
  name,
  DATE_FORMAT(date, '%d/%m/%Y') AS date,
  place,
  status
FROM events
ORDER BY events.date DESC
  `;
  db.query(q, (err, rows) => {
    if (err) return res.status(500).send(err);
    res.status(200).json(rows);
  });
});

router.post("/addNewEvent", (req, res) => {
  console.log(req.body);
  const { eventName, eventDate, eventLocation, eventPhotographer } = req.body;

  const queryToFindPhotogId =
    "SELECT id FROM `users` WHERE userType=? AND userName=?";

  db.query(
    queryToFindPhotogId,
    ["photographer", eventPhotographer],
    (err, result) => {
      if (err) return res.status(500).send("fail");

      if (!result || result.length === 0 || result[0].id == null) {
        return res.status(404).send("no photographer found");
      }

      const photographer_id = result[0].id;

      const q =
        "INSERT INTO events (photographer_id, name, date, place, status) VALUES (?, ?, ?, ?, ?)";

      db.query(
        q,
        [photographer_id, eventName, eventDate, eventLocation, "active"],
        (err) => {
          if (err) return res.status(500).send("fail");
          return res.send("success");
        },
      );
    },
  );
});

router.put("/:id", (req, res) => {
  const { id } = req.params;

  const { photographerName, name, date, place, status } = req.body;

  const pId =
    "SELECT id FROM users WHERE userType='photographer' AND userName=?";

  db.query(pId, [photographerName], (err, rows) => {
    if (err) return res.status(500).send(err);

    if (rows.length === 0) {
      return res.status(400).send("photographer not found");
    }

    const photographerId = rows[0].id;

    const q =
      "UPDATE events SET photographer_id=?, name=?, date=?, place=?, status=? WHERE id=?";

    db.query(q, [photographerId, name, date, place, status, id], (err2) => {
      if (err2) return res.status(500).send(err2);
      res.status(200).send("updated");
    });
  });
});
router.post("/getPhotogId", (req, res) => {
  const { photographerId } = req.body;
  const q = "select userName FROM users WHERE id=?";
  db.query(q, [photographerId], (err, result) => {
    if (err) return res.status(500).send(err);
    res.status(200).json(result);
  });
});

router.delete("/:id", (req, res) => {
  const { id } = req.params;

  const q = "DELETE FROM events WHERE id=?";
  db.query(q, [id], (err, result) => {
    if (err) return res.status(500).send(err);
    res.status(200).send("deleted");
  });
});

module.exports = router;
