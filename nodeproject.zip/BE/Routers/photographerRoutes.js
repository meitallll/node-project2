const express = require("express");
const router = express.Router();

const dbSingleton = require("../../DB/dbSingelton");
const db = dbSingleton.getConnection();

router.get("/", (req, res) => {
  const q = `
    SELECT
      *
    FROM users
    WHERE userType=?
  `;
  db.query(q, ["photographer"], (err, rows) => {
    if (err) return res.status(500).send(err);
    res.status(200).json(rows);
  });
});
module.exports = router;
