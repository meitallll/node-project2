const path = require("path");
const eventsRoutes=require('./Routers/eventsRoutes');
const express = require("express");
const loginRoutes = require("./Routers/loginRoutes");
const photographerRoutes=require('./Routers/photographerRoutes');
const servicesRoutes=require('./Routers/servicesRoutes');
const app = express();
const session = require("express-session");
const port = process.env.PORT || 3000;
app.use(express.json());
app.use(
  session({
    secret: "your_secret_key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // For HTTPS use true
  }),
);


app.use(express.static(path.join(__dirname, "../FE")));
app.use(express.urlencoded({ extended: false }));




app.use("/login", loginRoutes);
app.use("/events",eventsRoutes);
app.use("/photogs", photographerRoutes);
app.use("/services", servicesRoutes);





app.use((req, res, next) => {
  res.status(200).sendFile(path.join(__dirname, "../FE", "login.html"));
});

app.listen(port);
