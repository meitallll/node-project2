const servicesListEl = document.getElementById("services");

function renderServices(Services) {
  if (!Services || Services.length === 0) {
    servicesListEl.innerHTML = `<p class="card-info">אין צלמים להצגה.</p>`;
    return;
  }

  const html = Services.map((ev) => {
    const name = ev.type ?? "";
    

    return `
      <div class="service">
        <h3>${name}</h3>
      </div>
    `;
  }).join("");

  servicesListEl.innerHTML = html;
}

async function loadservices() {
  try {
    const res = await fetch("/services");
    if (!res.ok) {
      servicesListEl.innerHTML = `<p class="card-info">שגיאה בטעינת צלמים (סטטוס ${res.status})</p>`;
      return;
    }

    const services = await res.json();
    renderServices(services);
  } catch (err) {
    console.log(err);
    servicesListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (תקלה בחיבור)</p>`;
  }
}

loadservices();
