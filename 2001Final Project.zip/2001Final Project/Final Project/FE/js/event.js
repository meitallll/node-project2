const modal = document.getElementById("addEventModal");
const openBtn = document.getElementById("openAddEvent");
const closeBtn = document.getElementById("closeAddEvent");
const cancelBtn = document.getElementById("cancelAddEvent");

openBtn.onclick = () => {
  modal.style.display = "flex";
};

function closeModal() {
  modal.style.display = "none";
}

closeBtn.onclick = closeModal;
cancelBtn.onclick = closeModal;

const eventsListEl = document.getElementById("eventsList");

function statusColor(status) {
  if (!status) return "#666";
  const s = status.toLowerCase();
  if (s === "active" || status === "פעיל") return "green";
  if (s === "finished" || status === "הסתיים") return "blue";
  return "#666";
}

function renderEvents(events) {
  if (!events || events.length === 0) {
    eventsListEl.innerHTML = `<p class="card-info">אין אירועים להצגה.</p>`;
    return;
  }

  const html = events
    .map((ev) => {
      const name = ev.name ?? "";
      const date = ev.date ?? "";
      const place = ev.place ?? "";
      const photographerId = ev.photographer_id ?? "";
      const status = ev.status ?? "";

      return `
      <div class="card">
        <h3>${name}</h3>
        <p class="card-info">תאריך: ${date}</p>
        <p class="card-info">מקום: ${place}</p>
        <p class="card-info">צלם : ${photographerId}</p>
        <p class="card-info" style="color: ${statusColor(status)};">סטטוס: ${status}</p>
        <div class="card-actions">
          <button class="btn-small" type="button">צפה בתמונות</button>
          <button class="btn-small btn-secondary" type="button">הורד הכל</button>
        </div>
      </div>
    `;
    })
    .join("");

  eventsListEl.innerHTML = html;
}

async function loadEvents() {
  try {
    const res = await fetch("/events"); // השרת שלך מחובר ל-app.use("/events", eventsRoutes)
    if (!res.ok) {
      eventsListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (סטטוס ${res.status})</p>`;
      return;
    }

    const events = await res.json();
    renderEvents(events);
  } catch (err) {
    console.log(err);
    eventsListEl.innerHTML = `<p class="card-info">שגיאה בטעינת אירועים (תקלה בחיבור)</p>`;
  }
}

loadEvents();
function showPopup(message) {
  const popup = document.getElementById("popupAlert");
  popup.querySelector("p").innerText = message;
  popup.classList.add("show");
  setTimeout(() => popup.classList.remove("show"), 2500);
}

const form = document.getElementById("addEventForm");

function showPopup(message) {
  const popup = document.querySelector(".popupAlert");
  popup.querySelector("p").innerText = message;
  popup.classList.add("show");

  setTimeout(() => {
    popup.classList.remove("show");
  }, 2500);
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const body = new URLSearchParams(new FormData(form));

  const res = await fetch(form.action, {
    method: "POST",
    body: body,
  });

  const text = await res.text();

  if (text === "success") {
    showPopup("Event added successfully 🎉");
    form.reset();
    closeModal();
    loadEvents();
  } else if (text === "no photographer found") {
    showPopup("no photographer found ❌");
  } else {
    showPopup("fail ❌");
  }
});
