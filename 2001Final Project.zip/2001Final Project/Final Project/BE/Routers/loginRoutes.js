const dbSingleton = require("../../DB/dbSingelton");
const db = dbSingleton.getConnection();
const express = require("express");
const router = express.Router();

const validateUserExistance = (req, res, next) => {
  const { userName } = req.body;
  const query = "select * From users WHERE userName=?";
  db.query(query, [userName], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    console.log(results[0]);
    if (results.length > 0) {
      return res.status(409).json({ message: "User already exists" });
    } else next();
  });
};
const validateLogin = (req, res, next) => {
  const { userName, password } = req.body;
  const query = "select * From users WHERE userName=? and password=?";
  db.query(query, [userName, password], (err, results) => {
    if (err) {
      res.status(500).send(err);
      return;
    }
    console.log(results[0]);
    if (results.length > 0) {
      next();
    } else return res.status(409).json({ message: "User doesnt exists" });
  });
};

router.get("/", (req, res, next) => {
  res.redirect("../login.html");
});

router.post("/register", validateUserExistance, (req, res, next) => {
  const { userType, userName, age, email, password } = req.body;
  console.log(req.body);
  const query =
    "INSERT INTO users (userType, userName, password,email,age) VALUES (?, ?, ?,?,?)";

  db.query(
    query,
    [userType, userName, password, email, age],
    (err, results) => {
      if (err) {
        res.status(500).send(err);
        return;
      }

      res.redirect("/login.html");
    },
  );
});

router.post("/registered", validateLogin, (req, res, next) => {
  res.redirect("/home.html");
});

module.exports = router;
